<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <style>
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box
}
body {
    font-size: 16px;
    font-family: 'Montserrat', sans-serif;
}
@font-face {
  font-family: 'Montserrat';
  src: url('https://fonts.googleapis.com/css2?family=Montserrat&display=swap');
}

@font-face {
  font-family: 'Roboto';
  src: url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');
}

@font-face {
  font-family: 'Lato';
  src: url('https://fonts.googleapis.com/css2?family=Lato&display=swap');
}

.site-width {
    max-width: 1260px;
    margin: 0 auto;
    padding: 0 20px
}

a {
    text-decoration: none;
    color: currentColor
}

p { 
    margin: 0.25rem;
    line-height: 1.5
}

.page-template-shree_mahavirpurum table,.page-template-shree_foundation table {
    width: 100%
}

.page-template-shree_mahavirpurum table tr td,.page-template-shree_foundation table tr td {
    padding: 5px 0px
}

.button,button,input[type="button"] {
    color: #fff;
    padding: 5px 10px;
    border-radius: 5px;
    background: #212121;
    display: inline-block;
    text-decoration: none;
    border: 0
}

.info {
    width: 1000px
}

.info p:nth-child(1) {
    width: 15%;
    padding-left: 30px !important
}

.info p:nth-child(2) {
    width: 10%
}

.info p:nth-child(3) {
    width: 15%
}

.info p:nth-child(4) {
    width: 30%
}

.info p:nth-child(5) {
    width: 30%
}

.price {
    width: 250px
}

li.invoice-wrap {
    display: flex;
    text-align: left;
    padding: 10px;
    position: relative;
    border-bottom: 1px solid
}

li.invoice-wrap:nth-child(even) {
    background: #f4f4f4
}

li.invoice-wrap span {
    left: 10px;
    top: 13px;
    font-weight: bold;
    position: absolute
}

li.invoice-wrap .flex {
    display: flex
}

li.invoice-wrap .header {
    display: flex
}

li.invoice-wrap .info p {
    flex-grow: 1;
    padding: 0 10px
}

li.invoice-wrap .price {
    align-items: baseline;
    flex-direction: column
}

li.invoice-wrap.header {
    color: #fff;
    background: #212121
}

body.page-id-2 .entry-content {
    display: flex;
    min-height: 100vh;
    align-items: center;
    justify-content: space-between
}

body.page-id-2 .entry-content .box-wrap {
    flex-basis: 48%;
    text-align: center;
    font-size: 20px
}

body.page-id-2 .entry-content a {
    display: block;
    padding: 20px;
    box-shadow: 0 0 10px #ccc
}

li.invoice-wrap strong.highlight {
    display: block;
    margin-top: 5px;
    text-transform: uppercase
}
  </style>
  <title>Shree Mahavirpuram | Donaters List</title>
</head>
 <body class="page-template page-template-templates page-template-shree_mahavirpurum page-template-templatesshree_mahavirpurum-php page page-id-46 full-width single-author os-windows b-chrome bv-114">
        <div id="page">
            <div id="main">
                <div id="primary">
                    <div id="content">
                        <div>
                            <p>
                                <center>
                                <img decoding="async" loading="lazy" class="aligncenter size-full wp-image-41" src="<?php echo e(asset('assets/header-2.jpg')); ?>" alt="" width="1200" height="239"/>
                                </center>
                            </p>
                            <div id="container" class="invoice-listing" style="display: flex; justify-content: center; flex-wrap: wrap;">
                                <div class="invoice-header">
                                    <ul>
                                        <li class="invoice-wrap header">
                                            <div class="flex info">
                                                <p>Receipt No.</p>
                                                <p>Date</p>
                                                <p>Name</p>
                                                <p>Address</p>
                                            </div>
                                            <div class="flex price">
                                                <p>Total</p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="each-invoice" style="margin-top: -20px;">
                                    <ol>
                                        <li class="invoice-wrap">
                                            <span>1</span>
                                            <div class="flex info">
                                                <p>36</p>
                                                <p>April 13, 2023</p>
                                                <p>Test Mahavirpurum</p>
                                                <p>Test address</p>
                                            </div>
                                            <div class="flex price">
                                                <a class="button" href="#" rel="bookmark">View Invoices</a>
                                            </div>
                                        </li>
                                        <li class="invoice-wrap">
                                            <span>2</span>
                                            <div class="flex info">
                                                <p>32</p>
                                                <p>April 15, 2023</p>
                                                <p>Surbhi Shrimal</p>
                                                <p>Test</p>
                                            </div>
                                            <div class="flex price">
                                                <a class="button" href="#" rel="bookmark">View Invoices</a>
                                            </div>
                                        </li>
                                        <li class="invoice-wrap">
                                            <span>3</span>
                                            <div class="flex info">
                                                <p>33</p>
                                                <p>April 17, 2023</p>
                                                <p>Surbhi Malkin</p>
                                                <p>Test 2</p>
                                            </div>
                                            <div class="flex price">
                                                <a class="button" href="#" rel="bookmark">View Invoices</a>
                                            </div>
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #main -->
            <div class="clear"></div>
        </div>
        <!-- #page -->
        <!-- <script type='text/javascript' src='https://symmetricsolutionz.co.in/payment/wp-includes/js/jquery/jquery.min.js' id='jquery-core-js'></script>
        <script type='text/javascript' src='https://symmetricsolutionz.co.in/payment/wp-includes/js/jquery/jquery-migrate.min.js' id='jquery-migrate-js'></script>
        <script>
            function printDiv() {
                var divContents = document.getElementById("print-invoice").innerHTML;
                var a = window.open('', '', 'height=500, width=500');
                a.document.write('<html>');
                a.document.write('<body >');
                a.document.write(divContents);
                a.document.write('</body></html>');
                a.document.close();
                a.print();
            }
        </script>
        <script type="text/javascript">
            $(".each-invoice li.invoice-wrap").each(function(i) {
                $(this).find("span").text(++i);
            });
        </script> -->
  <!-- Bootstrap JS -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH /storage/ssd3/783/20855783/resources/views/listing.blade.php ENDPATH**/ ?>