<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.0/themes/smoothness/jquery-ui.css">
  <title>Shree Mahavirpuram | Invoice Generator</title>
</head>
<body>
  <center>
  <img class="" src="<?php echo e(asset('assets/header-2.jpg')); ?>" alt=""  width="1300" height="239"/>
  </center>
  <div class="container pb-5">
    <h1 class="text-center mt-5">Invoice Generator</h1>
    <form id="billForm" class="mt-5">
      <div class="form-group">
        <label for="date">Date:</label>
        <input type="text" class="form-control" id="date" name="date" required>
      </div>
      <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" class="form-control" id="name" name="name" required>
      </div>
      <div class="form-group">
        <label for="address">Address:</label>
        <input type="text" class="form-control" id="address" name="address" required>
      </div>
      <div class="form-group">
        <label for="totalAmount">Total Amount:</label>
        <input type="number" class="form-control" id="totalAmount" name="totalAmount" required>
      </div>
      <div class="form-group">
        <label for="split">Split Amount:</label>
        <input type="number" class="form-control" id="split" name="split" required>
      </div>
      <button type="submit" class="btn btn-primary">Generate Invoice</button>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script>
    var totalAmountInput = document.getElementById('totalAmount');
    var splitAmountInput = document.getElementById('split');

    totalAmountInput.addEventListener('keydown', function(event) {
      if (event.key === '-' || event.key === 'e') {
        event.preventDefault();
      }
    });

    splitAmountInput.addEventListener('keydown', function(event) {
      if (event.key === '-' || event.key === 'e') {
        event.preventDefault();
      }
    });

    $(function() {
      $("#date").datepicker({
        dateFormat: "dd MM yy",
        onSelect: function(dateText) {
          var selectedDate = $.datepicker.parseDate("dd MM yy", dateText);
          var formattedDate = $.datepicker.formatDate("dd MM yy", selectedDate);
          $(this).val(formattedDate);
        }
      });
    });

    $(document).ready(function() {
      var formCounter = 0;

      $('#billForm').submit(function(e) {
        e.preventDefault();

        var date = $('#date').val();
        var name = $('#name').val();
        var address = $('#address').val();
        var totalAmount = parseInt($('#totalAmount').val());
        var splitAmount = parseInt($('#split').val());

        var numberOfForms = Math.floor(totalAmount / splitAmount);
        var remainder = totalAmount % splitAmount;

        var formArray = [];
        var formHtml = '';

        for (var i = 0; i < numberOfForms; i++) {
          var formId = 'form_' + formCounter++;

          var formData = {
            date: date,
            amountReceived: splitAmount,
            paymentMode: '',
            chequeNumber: '',
            chequeDate: '',
            drawnDate: ''
          };

          formArray.push(formData);

          formHtml += `
            <h3 class="text-center mt-5">Invoice #${i}</h3>
            <form id="${formId}" class="mt-5">
              <div class="form-group">
                <label>Date:</label>
                <input type="text" class="form-control" value="${date}" readonly>
              </div>
              <div class="form-group">
                <label>Amount Received:</label>
                <input type="text" class="form-control" value="${splitAmount}" readonly>
              </div>
              <div class="form-group">
                <label>Payment Mode:</label>
                <div class="form-check">
                  <input type="radio" class="form-check-input" name="paymentMode${formId}" id="cheque${formId}" value="cheque">
                  <label class="form-check-label" for="cheque${formId}">Cheque</label>
                </div>
                <div class="form-check">
                  <input type="radio" class="form-check-input" name="paymentMode${formId}" id="cash${formId}" value="cash">
                  <label class="form-check-label" for="cash${formId}">Cash</label>
                </div>
              </div>
              <div class="form-group cheque-fields" style="display: none;">
                <label>Cheque Number:</label>
                <input type="text" class="form-control cheque-number" name="chequeNumber${formId}" id="chequeNumber${formId}">
              </div>
              <div class="form-group cheque-fields" style="display: none;">
                <label>Date:</label>
                <input type="text" class="form-control cheque-date" name="chequeDate${formId}" id="chequeDate${formId}">
              </div>
              <div class="form-group cheque-fields" style="display: none;">
                <label>Drawn Date:</label>
                <input type="text" class="form-control drawn-date" name="drawnDate${formId}" id="drawnDate${formId}">
              </div>
            </form>
          `;
        }

        if (remainder > 0) {
          var formId = 'form_' + formCounter++;

          var formData = {
            date: date,
            amountReceived: remainder,
            paymentMode: '',
            chequeNumber: '',
            chequeDate: '',
            drawnDate: ''
          };

          formArray.push(formData);

          formHtml += `
            <h3 class="text-center mt-5">Invoice #${i}</h3>
            <form id="${formId}" class="mt-5">
              <div class="form-group">
                <label>Date:</label>
                <input type="text" class="form-control" value="${date}" readonly>
              </div>
              <div class="form-group">
                <label>Amount Received:</label>
                <input type="text" class="form-control" value="${remainder}" readonly>
              </div>
              <div class="form-group">
                <label>Payment Mode:</label>
                <div class="form-check">
                  <input type="radio" class="form-check-input" name="paymentMode${formId}" id="cheque${formId}" value="cheque">
                  <label class="form-check-label" for="cheque${formId}">Cheque</label>
                </div>
                <div class="form-check">
                  <input type="radio" class="form-check-input" name="paymentMode${formId}" id="cash${formId}" value="cash">
                  <label class="form-check-label" for="cash${formId}">Cash</label>
                </div>
              </div>
              <div class="form-group cheque-fields" style="display: none;">
                <label>Cheque Number:</label>
                <input type="text" class="form-control cheque-number" name="chequeNumber${formId}" id="chequeNumber${formId}">
              </div>
              <div class="form-group cheque-fields" style="display: none;">
                <label>Date:</label>
                <input type="text" class="form-control cheque-date" name="chequeDate${formId}" id="chequeDate${formId}">
              </div>
              <div class="form-group cheque-fields" style="display: none;">
                <label>Drawn Date:</label>
                <input type="text" class="form-control drawn-date" name="drawnDate${formId}" id="drawnDate${formId}">
              </div>
            </form>
          `;
        }

        formHtml += `<button type="submit" class="btn btn-primary" id="submitInvoices">Submit Invoices</button>`;
        $('.container').append(formHtml);

        $('input[type="radio"]').change(function() {
          var formId = $(this).closest('form').attr('id');
          var paymentMode = $(this).val();
          var chequeFields = $(`#${formId} .cheque-fields`);
          
          if (paymentMode === 'cheque') {
            chequeFields.show();
          } else {
            chequeFields.hide();
          }

          var formData = formArray.find(function(item) {
            return item.paymentMode === '';
          });

          if (formData) {
            formData.paymentMode = paymentMode;
          }
        });
        $('.cheque-number').change(function() {
          var formId = $(this).closest('form').attr('id');
          var chequeNumber = $(this).val();

          var formData = formArray.find(function(item) {
            return item.paymentMode !== '' && item.chequeNumber === '';
          });

          if (formData) {
            formData.chequeNumber = chequeNumber;
          }
        });
        $(".cheque-date").datepicker({
          dateFormat: "dd MM yy",
          onSelect: function(dateText) {
            var formId = $(this).closest('form').attr('id');
            var formData = formArray.find(function(item) {
              return item.paymentMode !== '' && item.chequeDate === '';
            });

            if (formData) {
              formData.chequeDate = dateText;
            }
          }
        });

        $(".drawn-date").datepicker({
          dateFormat: "dd MM yy",
          onSelect: function(dateText) {
            var formId = $(this).closest('form').attr('id');
            var formData = formArray.find(function(item) {
              return item.paymentMode !== '' && item.drawnDate === '';
            });

            if (formData) {
              formData.drawnDate = dateText;
            }
          }
        });

        $('#submitInvoices').click(function() {
          console.log(formArray);
          // Submit the form data to the server
        });
      });
    });
  </script>
</body>
</html>
<?php /**PATH /storage/ssd3/783/20855783/resources/views/bill_gen.blade.php ENDPATH**/ ?>