<?php

namespace App\Http\Controllers;
use App\Models\InvoiceModel;
use App\Models\InvoiceDetailModel;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    //
    public function createInvoice(Request $request){
        // foreach($request as $x){
        // }
        // InvoiceModel::create();
    }
}
